import os
import requests
from PIL import Image
import io
import base64

# Replace with your actual token
LLMFOUNDRY_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImRldmFyYWtvbmRhLmt1c2hpZXNod2FyQHN0cmFpdmUuY29tIn0.l6JodwUbmGB_eiYggu75kD0G9JAQrW2ckUWr--6xlwY"  

image_path = "./data/credit_card.png"
output_txt_path = "./data/credit-card.txt"

try:
    with Image.open(image_path) as img:
        # Convert image to base64
        buffered = io.BytesIO()
        img.save(buffered, format="PNG")
        img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")

    response = requests.post(
        "https://llmfoundry.straive.com/openai/v1/chat/completions",
        headers={"Authorization": f"Bearer {LLMFOUNDRY_TOKEN}:my-test-project"},
        json={
            "model": "gpt-4o-mini",  # or other suitable model
            "messages": [
                {
                    "role": "user",
                    "content": f"Extract 16 numbers in image which are placed inline with space between each occurance of 4 numbers:\n\n![credit card]({img_str})",
                }
            ],
        },
    )

    response.raise_for_status()  # Raise an exception for bad status codes
    
    extracted_text = response.json()["choices"][0]["message"]["content"]
    # Remove any spaces and newlines from the extracted number
    card_number = extracted_text.replace(" ", "").replace("\n", "")
    print(card_number)

    with open(output_txt_path, "w") as f:
        f.write(card_number)

except Exception as e:
    print(f"Error: {e}")