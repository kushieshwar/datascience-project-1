from datetime import datetime, date

# Read the contents of the dates.txt file
with open('/data/dates.txt', 'r') as file:
    dates = file.readlines()

# Convert all dates to a common format (YYYY-MM-DD)
formatted_dates = []
for date_str in dates:
    try:
        date_obj = datetime.strptime(date_str.strip(), '%Y-%m-%d')
        formatted_date = date_obj.strftime('%Y-%m-%d')
        formatted_dates.append(formatted_date)
    except ValueError:
        try:
            date_obj = datetime.strptime(date_str.strip(), '%b %d, %Y')
            formatted_date = date_obj.strftime('%Y-%m-%d')
            formatted_dates.append(formatted_date)
        except ValueError:
            try:
                date_obj = datetime.strptime(date_str.strip(), '%Y/%m/%d %H:%M:%S')
                formatted_date = date_obj.strftime('%Y-%m-%d')
                formatted_dates.append(formatted_date)
            except ValueError:
                try:
                    date_obj = datetime.strptime(date_str.strip(), '%d-%b-%Y')
                    formatted_date = date_obj.strftime('%Y-%m-%d')
                    formatted_dates.append(formatted_date)
                except ValueError:
                    print(f"Unable to parse date: {date_str.strip()}")

# Count the number of Wednesdays
wednesdays = 0
for date_str in formatted_dates:
    date_obj = datetime.strptime(date_str, '%Y-%m-%d').date()
    if date_obj.weekday() == 2:  # 2 represents Wednesday
        wednesdays += 1

# Write the count to the dates-wednesdays.txt file
with open('./data/dates-wednesdays.txt', 'w') as file:
    file.write(str(wednesdays))