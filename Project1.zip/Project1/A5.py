import os
from glob import glob

# Get list of log files sorted by modification time
log_files = sorted(glob('/data/logs/*.log'), key=os.path.getmtime, reverse=True)

# Read the first line of the 10 most recent log files
recent_lines = []
for log_file in log_files[:10]:
    with open(log_file, 'r') as file:
        first_line = file.readline().strip()
        recent_lines.append(first_line)

# Write the lines to a new file
with open('./data/logs-recent.txt', 'w') as file:
    for line in recent_lines:
        file.write(line + '\n')