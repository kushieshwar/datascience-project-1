import subprocess
import os

# Define the path to the Markdown file
file_path = '/data/format.md'

# Check if the file exists
if os.path.exists(file_path):
    # Run Prettier to format the file in-place
    try:
        subprocess.run(['npx', 'prettier', '--write', file_path], check=True)
        print(f"Formatted {file_path} successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error formatting file: {e}")
else:
    print(f"File {file_path} does not exist.")