import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load comments from file
with open('./data/comments.txt', 'r') as f:
    comments = [line.strip() for line in f]

# Use TF-IDF to create embeddings
vectorizer = TfidfVectorizer()
embeddings = vectorizer.fit_transform(comments)

# Initialize variables to track the most similar pair
max_similarity = -1
most_similar_indices = (-1, -1)

# Compare all pairs of comments
for i in range(len(comments)):
    for j in range(i + 1, len(comments)):
        similarity = cosine_similarity(embeddings[i], embeddings[j])[0][0]

        if similarity > max_similarity:
            max_similarity = similarity
            most_similar_indices = (i, j)

# Write the most similar comments to file
with open('./data/comments-similar.txt', 'w') as outfile:
    outfile.write(comments[most_similar_indices[0]] + '\n')
    outfile.write(comments[most_similar_indices[1]] + '\n')

print(f"Most similar comments written to /data/comments-similar.txt")