import json

# Read contacts from file
with open('/data/contacts.json', 'r') as file:
    contacts = json.load(file)

# Sort contacts
contacts_sorted = sorted(contacts, key=lambda x: (x['last_name'], x['first_name']))

# Write sorted contacts to file
with open('./data/contacts-sorted.json', 'w') as file:
    json.dump(contacts_sorted, file, indent=4)
    print(contacts_sorted)