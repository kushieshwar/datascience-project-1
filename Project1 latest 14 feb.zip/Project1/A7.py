import os
import requests

# Read email content
with open("./data/email.txt", "r") as f:
    email_content = f.read()
print(email_content)
# Prepare LLM request
LLM_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImRldmFyYWtvbmRhLmt1c2hpZXNod2FyQHN0cmFpdmUuY29tIn0.l6JodwUbmGB_eiYggu75kD0G9JAQrW2ckUWr--6xlwY"  # Provided token
headers = {"Authorization": f"Bearer {LLM_TOKEN}:my-test-project"}
prompt = f"""Extract the sender's email address from the following email:\n\n{email_content}\n\nOutput ONLY the email address."""
json_data = {"model": "gpt-4o-mini", "messages": [{"role": "user", "content": prompt}]}

# Make LLM request
try:
    response = requests.post("https://llmfoundry.straive.com/openai/v1/chat/completions", headers=headers, json=json_data)
    response.raise_for_status()  # Raise an exception for bad status codes (4xx or 5xx)
    extracted_email = response.json()['choices'][0]['message']['content'].strip()

    # Write extracted email to file
    with open("./data/email-sender.txt", "w") as outfile:
        outfile.write(extracted_email)

except requests.exceptions.RequestException as e:
    print(f"Error communicating with LLM: {e}")
except (KeyError, IndexError) as e:
    print(f"Error parsing LLM response: {e}")
    print(response.json()) # Print the full response for debugging
except Exception as e:
    print(f"An unexpected error occurred: {e}")