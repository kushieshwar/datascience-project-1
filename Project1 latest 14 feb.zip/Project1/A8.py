import os
import requests
from PIL import Image
import io

# Replace with your actual token and project ID
LLMFOUNDRY_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImRldmFyYWtvbmRhLmt1c2hpZXNod2FyQHN0cmFpdmUuY29tIn0.l6JodwUbmGB_eiYggu75kD0G9JAQrW2ckUWr--6xlwY"  #  os.environ.get('LLMFOUNDRY_TOKEN')  #  Use environment variable in real usage
PROJECT_ID = "my-test-project"  #  os.environ.get('LLMFOUNDRY_PROJECT_ID') # Use environment variable in real usage

def extract_credit_card_number(image_path, llm_token, project_id):
    """
    Extracts the credit card number from an image using an LLM.

    Args:
        image_path (str): Path to the image file.
        llm_token (str): LLM Foundry API token.
        project_id (str): LLM Foundry project ID.

    Returns:
        str: The extracted credit card number (without spaces), or None if extraction fails.
    """
    try:
        with open(image_path, "rb") as image_file:
            image_data = image_file.read()

        # Prepare the request to the LLM
        headers = {
            "Authorization": f"Bearer {llm_token}:{project_id}",
            "Content-Type": "application/json",  # Important for JSON payload
        }

        payload = {
            "model": "gemini-1.5-flash-8b",  # Or your preferred model
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "Extract the credit card number from the image.  Return ONLY the number, without any spaces or other characters."},
                        {"type": "image_url", "image_url": {"url": "data:image/png;base64," +  ImageToBase64(image_path)}} #  "data:image/png;base64," + base64.b64encode(image_data).decode("utf-8")
                    ],
                }
            ],
        }

        # Send the request to the LLM
        response = requests.post(
            "https://llmfoundry.straive.com/gemini/v1beta/openai/chat/completions",
            headers=headers,
            json=payload,
        )
        response.raise_for_status()  # Raise an exception for bad status codes

        response_json = response.json()
        # Extract the credit card number from the LLM's response
        try:
            credit_card_number = response_json["choices"][0]["message"]["content"].strip().replace(" ", "")
            return credit_card_number
        except (KeyError, IndexError):
            print(f"Error parsing LLM response: {response_json}")
            return None

    except FileNotFoundError:
        print(f"Error: Image file not found at {image_path}")
        return None
    except requests.exceptions.RequestException as e:
        print(f"Error during API request: {e}")
        return None
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return None

def ImageToBase64(image_path):
    """
    Converts an image to a base64 string.

    Args:
        image_path (str): The path to the image file.

    Returns:
        str: The base64 encoded string of the image, or None if an error occurs.
    """
    try:
        with open(image_path, "rb") as image_file:
            image_data = image_file.read()
        import base64
        return base64.b64encode(image_data).decode("utf-8")
    except FileNotFoundError:
        print(f"Error: Image file not found at {image_path}")
        return None
    except Exception as e:
        print(f"An error occurred during image conversion: {e}")
        return None


def main():
    image_path = "./data/credit_card.png"  #  Or wherever your image is located
    output_file_path = "./data/credit-card.txt"

    credit_card_number = extract_credit_card_number(image_path, LLMFOUNDRY_TOKEN, PROJECT_ID)

    if credit_card_number:
        try:
            with open(output_file_path, "w") as f:
                f.write(credit_card_number)
            print(f"Credit card number extracted and saved to {output_file_path}")
        except IOError as e:
            print(f"Error writing to file: {e}")
    else:
        print("Failed to extract credit card number.")


if __name__ == "__main__":
    # Create a dummy image file for testing if it doesn't exist
    if not os.path.exists("/data"):
        os.makedirs("/data")
    if not os.path.exists("./data/credit_card.png"):
        # Create a simple dummy image (replace with your actual image creation if needed)
        from PIL import Image
        img = Image.new('RGB', (100, 50), color = 'red')
        img.save("/data/credit_card.png")

    main()