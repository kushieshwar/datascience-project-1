from flask import Flask, request, jsonify
import os

app = Flask(__name__)

@app.route('/run', methods=['POST'])
def run_task():
    task_description = request.args.get('task')
    if not task_description:
        return "Task description is required", 400

    try:
        # Here you would parse the task description and execute the task
        # For now, we'll just return a placeholder response
        return f"Executed task: {task_description}", 200
    except ValueError as e:
        return str(e), 400
    except Exception as e:
        return str(e), 500

@app.route('/read', methods=['GET'])
def read_file():
    file_path = request.args.get('path')
    if not file_path or not os.path.exists(file_path):
        return "", 404

    with open(file_path, 'r') as file:
        content = file.read()
    return content, 200

if __name__ == '__main__':
    app.run(debug=True)