import sqlite3

# Database file path
db_file = './data/ticket-sales.db'
# Output file path
output_file = './data/ticket-sales-gold.txt'

try:
    # Connect to the SQLite database
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()

    # Execute the query to calculate total sales for "Gold" tickets
    cursor.execute("SELECT SUM(units * price) FROM tickets WHERE type = 'Gold'")
    result = cursor.fetchone()

    # Extract the total sales (or 0 if no "Gold" tickets exist)
    total_sales = result[0] if result[0] is not None else 0

    # Write the total sales to the output file
    with open(output_file, 'w') as f:
        f.write(str(total_sales))

    print(f"Total sales for Gold tickets: {total_sales}")

except sqlite3.Error as e:
    print(f"An error occurred: {e}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
finally:
    # Close the connection
    if conn:
        conn.close()