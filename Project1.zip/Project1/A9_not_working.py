import numpy as np
from sentence_transformers import SentenceTransformer, util

# Load the Sentence Transformer model (using a smaller, faster model for demonstration)
model = SentenceTransformer('all-MiniLM-L6-v2')

# Load comments from file
with open('./data/comments.txt', 'r') as f:
    comments = [line.strip() for line in f]

# Generate embeddings for each comment
embeddings = model.encode(comments)

# Initialize variables to track the most similar pair
max_similarity = -1
most_similar_indices = (-1, -1)

# Compare all pairs of comments
for i in range(len(comments)):
    for j in range(i + 1, len(comments)):
        similarity = util.cos_sim(embeddings[i], embeddings[j]).item()  # Get scalar similarity value

        if similarity > max_similarity:
            max_similarity = similarity
            most_similar_indices = (i, j)

# Write the most similar comments to file
with open('./data/comments-similar.txt', 'w') as outfile:
    outfile.write(comments[most_similar_indices[0]] + '\n')
    outfile.write(comments[most_similar_indices[1]] + '\n')


print(f"Most similar comments written to /data/comments-similar.txt")