import os
import json

# Set the directory to search for Markdown files
docs_dir = '/data/docs/'

# Initialize the index dictionary
index = {}

# Iterate through all files in the directory
for root, dirs, files in os.walk(docs_dir):
    for file in files:
        # Check if the file is a Markdown file
        if file.endswith('.md'):
            # Get the full path of the file
            file_path = os.path.join(root, file)
            # Remove the prefix from the file path
            relative_path = file_path.replace(docs_dir, '')
            # Read the contents of the file
            with open(file_path, 'r') as f:
                contents = f.read()
            # Find the first occurrence of an H1 header
            title = None
            for line in contents.split('\n'):
                if line.startswith('# '):
                    title = line[2:].strip()
                    break
            # Add the file and its title to the index
            index[relative_path] = title
print(index)
# Write the index to a JSON file
"""with open(os.path.join(docs_dir, './data/index.json'), 'w') as f:
    json.dump(index, f, indent=2)"""
import json

with open('./data/index.json', 'w') as file:
    json.dump(index, file, indent=2)